#pragma once
#include "Simbolo.h"
#include <unordered_map>
#include <vector>
#include <stdexcept>

class TabelaSimbolos {
    std::vector<std::unordered_map<std::string, Simbolo>> escopos;
    int nivelAtual = 0;

public:
    TabelaSimbolos() { entrarEscopo(); }
        
    int getNivelAtual() const { return nivelAtual; } // Adicione este getter

    void entrarEscopo() {
        escopos.push_back({});
        nivelAtual++;
    }
    
    void sairEscopo() {
        if (escopos.size() > 1) {
            escopos.pop_back();
            nivelAtual--;
        }
    }

    bool inserirSimbolo(const Simbolo& simbolo) {
        auto& escopoAtual = escopos.back();
        
        // Verifica se já existe no mesmo escopo
        if (escopoAtual.find(simbolo.nome) != escopoAtual.end()) {
            return false;
        }
        
        escopoAtual[simbolo.nome] = simbolo;
        return true;
    }

    Simbolo* buscarSimbolo(const std::string& nome) {
        // Busca do escopo mais interno para o mais externo
        for (auto it = escopos.rbegin(); it != escopos.rend(); ++it) {
            auto found = it->find(nome);
            if (found != it->end()) {
                return &found->second;
            }
        }
        return nullptr;
    }

    // Busca apenas no escopo atual
    Simbolo* buscarNoEscopoAtual(const std::string& nome) {
        auto& escopoAtual = escopos.back();
        auto found = escopoAtual.find(nome);
        if (found != escopoAtual.end()) {
            return &found->second;
        }
        return nullptr;
    }
};