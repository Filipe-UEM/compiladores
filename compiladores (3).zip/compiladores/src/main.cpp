#include <iostream>
#include <fstream>
#include "antlr4-runtime.h"
#include "MinhaLinguagemLexer.h"
#include "MinhaLinguagemParser.h"
#include "SemanticoVisitor.h"
// #include "GeradorCodigoLLVM.h"

using namespace antlr4;


//
//
//
//
//
// REMOVER O LLVM E AS SUAS CHAMADAS
//
//
//
//
//
//

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Uso: " << argv[0] << " <arquivo>\n";
        return 1;
    }

    std::ifstream stream(argv[1]);
    ANTLRInputStream input(stream);
    
    MinhaLinguagemLexer lexer(&input);
    CommonTokenStream tokens(&lexer);
    
    MinhaLinguagemParser parser(&tokens);
    MinhaLinguagemParser::ProgramaContext* tree = parser.programa();

    // Executar análise semântica
    SemanticoVisitor semantico;
    semantico.visitPrograma(tree);

    // Reportar erros
    for (const auto& erro : semantico.getErros()) {
        std::cerr << erro << std::endl;
    }

    if (!semantico.getErros().empty()) {
        std::cerr << "\n[FALHA] Compilação terminada com " 
                  << semantico.getErros().size() << " erros\n";
        return 1;
    }

    std::cout << "[SUCESSO] Programa semanticamente correto!\n";
    return 0;


    // TabelaSimbolos tabela;
    // AnalisadorSemantico analisador(tabela);
    // analisador.visitPrograma(tree);  
    
    // // Salvar código LLVM em arquivo
    // gerador.imprimirIR("output.ll");
    
    // std::cout << "[SUCESSO] Código LLVM gerado em output.ll\n";
}