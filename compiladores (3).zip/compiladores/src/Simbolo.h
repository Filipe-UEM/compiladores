#pragma once
#include <string>
#include <vector>

enum class TipoDado {
    INT, 
    FLOAT, 
    CHAR, 
    STRING, 
    VOID, 
    CLASSE, 
    POINTER, 
    VETOR_INT,    
    VETOR_FLOAT,  
    VETOR_CHAR,   
    VETOR_STRING, 
    INVALIDO
};

enum class Categoria {
    VARIAVEL, FUNCAO, CLASSE, PARAMETRO
};

struct Simbolo {
    std::string nome = "";
    TipoDado tipo = TipoDado::INVALIDO;
    Categoria categoria;
    bool isVetor;
    int nivelEscopo;
    std::vector<TipoDado> tiposParametros = {};

    // Construtor para variáveis
    Simbolo(std::string nome, TipoDado tipo, Categoria cat, bool isVetor, int nivel)
        : nome(nome), tipo(tipo), categoria(cat), isVetor(isVetor), nivelEscopo(nivel) {}
    
    // Construtor para funções
    Simbolo(std::string nome, TipoDado tipo, std::vector<TipoDado> params, int nivel)
        : nome(nome), tipo(tipo), categoria(Categoria::FUNCAO), isVetor(false),
          nivelEscopo(nivel), tiposParametros(params) {}
};